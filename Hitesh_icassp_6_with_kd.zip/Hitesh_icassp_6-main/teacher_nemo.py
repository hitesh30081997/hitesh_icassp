"""
teacher_nemo.py
Frozen teacher: NVIDIA NeMo `slu_conformer_transformer_large_slurp`.

The teacher is a Conformer encoder + Transformer decoder that emits a semantics
string in exactly the format it was trained on (NeMo process_slurp_data.py):

    {'scenario': 'alarm', 'action': 'set', 'entities': [{'type': 'time', 'filler': 'five am'}]}

For a batch of (clean) waveforms this wrapper provides three kinds of knowledge:

  1. encode()          Conformer encoder states (B, T_t, 512), 40 ms frames.
                       -> frame-level feature distillation.
  2. intent_logprobs() Teacher log-likelihood of every student intent, computed by
                       teacher-forcing the prefix "{'scenario': 'X', 'action': 'Y',"
                       through the decoder. Softmax over these = the teacher's
                       intent posterior in the STUDENT's label space.
                       -> soft-label intent distillation.
  3. decode()          Greedy-decoded semantics strings (entities = slot fillers).
                       -> converted to the student's tagged-transcript format
                          (see semantics_to_tagged_text) for slot distillation.

Compatible with NeMo 1.23.0 and 2.7.3. On 2.x it patches the three known
incompatibilities with this 1.13-era checkpoint (classifier type, freeze() in
transcribe(), tuple output of the greedy generator).
"""
import ast
import os
import re
import tarfile
import urllib.request

import torch

MODEL_URL = (
    "https://api.ngc.nvidia.com/v2/models/nvidia/nemo/"
    "slu_conformer_transformer_large_slurp/versions/1.13.0/files/"
    "slu_conformer_transformer_large_slurp.nemo"
)
DEFAULT_NEMO_PATH = "slu_conformer_transformer_large_slurp.nemo"


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def download_teacher(path=DEFAULT_NEMO_PATH):
    if not os.path.exists(path):
        print(f"[teacher] downloading {MODEL_URL}\n          -> {path}")
        urllib.request.urlretrieve(MODEL_URL, path)
    return path


def _unwrap(x):
    """NeMo 2.x returns tuples where 1.x returned tensors; take the first item."""
    return x[0] if isinstance(x, (tuple, list)) else x


def load_teacher_model(nemo_path, device):
    from omegaconf import open_dict
    from nemo.collections.asr.models import SLUIntentSlotBPEModel

    cfg = SLUIntentSlotBPEModel.restore_from(nemo_path, return_config=True)
    target = cfg.classifier.get("_target_", "")

    # NeMo 1.x builds the checkpoint's bare MultiLayerPerceptron fine. NeMo 2.x
    # expects a TokenClassifier (".mlp" attribute), so swap it and remap weights.
    needs_patch = "TokenClassifier" not in target
    if needs_patch:
        try:
            from nemo.collections.asr.parts.submodules.token_classifier import TokenClassifier  # noqa: F401
        except ImportError:
            needs_patch = False  # NeMo 1.x: original config works as-is

    if not needs_patch:
        model = SLUIntentSlotBPEModel.restore_from(nemo_path, map_location=device)
    else:
        with open_dict(cfg):
            cfg.classifier._target_ = (
                "nemo.collections.asr.parts.submodules.token_classifier.TokenClassifier"
            )
        model = SLUIntentSlotBPEModel.restore_from(
            nemo_path, override_config_path=cfg, map_location=device, strict=False
        )
        with tarfile.open(nemo_path, "r:*") as tar:
            member = next(m for m in tar.getmembers() if m.name.endswith("model_weights.ckpt"))
            state = torch.load(tar.extractfile(member), map_location=device)
        state = {
            (k.replace("classifier.", "classifier.mlp.", 1) if k.startswith("classifier.layer") else k): v
            for k, v in state.items()
        }
        missing, unexpected = model.load_state_dict(state, strict=False)
        bad = [k for k in missing + unexpected
               if k.startswith(("classifier", "encoder", "decoder", "embedding"))]
        if bad:
            raise RuntimeError(f"[teacher] weight mismatch after remapping: {bad[:10]}")
        print("[teacher] patched classifier for NeMo 2.x")

    model.to(device).eval()
    for p in model.parameters():
        p.requires_grad = False
    return model


# --------------------------------------------------------------------------- #
# Teacher wrapper
# --------------------------------------------------------------------------- #
class NemoSLUTeacher:
    def __init__(self, nemo_path, intent_list, intent_to_scenario_action, device,
                 intent_chunk=16):
        self.device = torch.device(device)
        self.model = load_teacher_model(nemo_path, self.device)
        self.intent_list = list(intent_list)
        self.intent_chunk = intent_chunk
        self.dim = int(self.model.cfg.encoder.d_model)

        self.tok = self.model.tokenizer
        self.bos = self.tok.bos_id
        if self.bos is None or self.bos < 0:
            raise RuntimeError("[teacher] tokenizer has no BOS id; cannot score intents")
        self.intent_pairs = [intent_to_scenario_action[i] for i in self.intent_list]
        # Default guess; replaced by calibrate() with the teacher's real output format
        # (this checkpoint writes '|' where str(dict) would have ',').
        self.prefix_parts = ("{'scenario': '", "'| 'action': '", "'|")
        self._build_prefixes()

    def _build_prefixes(self):
        a, b, c = self.prefix_parts
        seqs = [[self.bos] + list(self.tok.text_to_ids(f"{a}{sc}{b}{ac}{c}"))
                for sc, ac in self.intent_pairs]
        max_len = max(len(x) for x in seqs)
        ids = torch.zeros(len(seqs), max_len, dtype=torch.long)
        for i, x in enumerate(seqs):
            ids[i, : len(x)] = torch.tensor(x)
        self.prefix_ids = ids.to(self.device)                                  # (K, L)
        self.prefix_lens = torch.tensor([len(x) for x in seqs], device=self.device)

    @torch.no_grad()
    def calibrate(self, wav, wav_lens, show=3):
        """Learn the exact scenario/action prefix format from the teacher's own
        greedy outputs, so intent scoring teacher-forces text it really produces."""
        enc, lens = self.encode(wav.to(self.device), wav_lens.to(self.device))
        raws = self.decode(enc, lens)
        for r in raws[:show]:
            print(f"[teacher] raw output: {r!r}")
        for r in raws:
            m = PREFIX_RE.match(r.strip())
            if m:
                self.prefix_parts = (m["a"], m["b"], m["c"])
                break
        else:
            print("[teacher] WARNING: could not infer prefix format from outputs; using default")
        a, b, c = self.prefix_parts
        sc, ac = self.intent_pairs[0]
        print(f"[teacher] intent prefix format: {a}{sc}{b}{ac}{c}")
        self._build_prefixes()
        n_ok = sum(parse_semantics(r) is not None for r in raws)
        print(f"[teacher] parsed {n_ok}/{len(raws)} calibration outputs")
        return raws

    # ----------------------------------------------------------------------- #
    @torch.no_grad()
    def encode(self, wav, wav_lens):
        """wav: (B, N) float at 16 kHz, wav_lens: (B,) -> enc (B, T, D), enc_lens (B,)"""
        m = self.model
        feats, feat_lens = m.preprocessor(input_signal=wav, length=wav_lens)
        enc, enc_lens = m.encoder(audio_signal=feats, length=feat_lens)
        return enc.transpose(1, 2).contiguous(), enc_lens  # BxDxT -> BxTxD

    def _enc_mask(self, enc, enc_lens):
        from nemo.collections.asr.parts.utils.slu_utils import get_seq_mask
        return get_seq_mask(enc, enc_lens)

    @torch.no_grad()
    def intent_logprobs(self, enc, enc_lens):
        """(B, K) teacher log-likelihood of each intent prefix (student intent order)."""
        m = self.model
        B, T, D = enc.shape
        enc_mask = self._enc_mask(enc, enc_lens)

        inp_all = self.prefix_ids[:, :-1]                                       # (K, L-1)
        tgt_all = self.prefix_ids[:, 1:]
        L1 = inp_all.shape[1]
        valid_all = (torch.arange(L1, device=self.device)[None, :]
                     < (self.prefix_lens - 1)[:, None]).float()                 # (K, L-1)

        K = inp_all.shape[0]
        scores = torch.empty(B, K, device=self.device)
        for s in range(0, K, self.intent_chunk):
            e = min(K, s + self.intent_chunk)
            k = e - s
            inp = inp_all[s:e].unsqueeze(0).expand(B, k, L1).reshape(B * k, L1)
            tgt = tgt_all[s:e].unsqueeze(0).expand(B, k, L1).reshape(B * k, L1)
            dmask = valid_all[s:e].unsqueeze(0).expand(B, k, L1).reshape(B * k, L1)
            enc_b = enc.unsqueeze(1).expand(B, k, T, D).reshape(B * k, T, D)
            emask_b = enc_mask.unsqueeze(1).expand(B, k, T).reshape(B * k, T)

            h = m.embedding(inp)
            h = _unwrap(m.decoder(h, dmask, enc_b, emask_b))
            logits = m.classifier(hidden_states=h).float()
            logp = torch.log_softmax(logits, dim=-1)  # idempotent if already log-probs
            tok_lp = logp.gather(-1, tgt.unsqueeze(-1)).squeeze(-1) * dmask
            scores[:, s:e] = tok_lp.sum(-1).view(B, k)
        return scores

    @property
    def sep(self):
        """Structural separator incl. trailing space as the teacher writes it, e.g. '| ' or ', '."""
        b = self.prefix_parts[1]                     # e.g. "'| 'action': '"
        return b[1: b.index("'action'")]

    def render(self, scenario, action, entities):
        return render_semantics(scenario, action, entities, self.sep)

    def encode_target(self, text):
        """Semantics string -> [BOS] + ids + [EOS] (teacher's training layout)."""
        return [self.bos] + list(self.tok.text_to_ids(text)) + [self.tok.eos_id]

    def ids_to_text(self, ids):
        """Same detokenisation the teacher's sequence generator uses."""
        return "".join(self.tok.tokenizer.decode_ids(list(ids)))

    @torch.no_grad()
    def forced(self, enc, enc_lens, dec_inp, dec_mask):
        """Teacher-forced pass: log-probs (B, L, V) and final decoder states (B, L, D)."""
        m = self.model
        h = m.embedding(dec_inp)
        h = _unwrap(m.decoder(h, dec_mask, enc, self._enc_mask(enc, enc_lens)))
        logp = torch.log_softmax(m.classifier(hidden_states=h).float(), dim=-1)
        return logp, h

    @torch.no_grad()
    def decode(self, enc, enc_lens):
        """Greedy semantics strings, one per utterance."""
        sg = self.model.sequence_generator
        tokens = _unwrap(sg(enc, self._enc_mask(enc, enc_lens)))
        return sg.decode_semantics_from_tokens(tokens)


# --------------------------------------------------------------------------- #
# Teacher output -> student label space
# --------------------------------------------------------------------------- #
PREFIX_RE = re.compile(
    r"^(?P<a>.*?'scenario'\s*:\s*')(?P<sc>[^']*)(?P<b>'\s*[,|]\s*'action'\s*:\s*')"
    r"(?P<ac>[^']*)(?P<c>'\s*[,|])"
)
_SC_RE = re.compile(r"'scenario'\s*:\s*'([^']*)'")
_AC_RE = re.compile(r"'action'\s*:\s*'([^']*)'")
_ENT_RE = re.compile(r"'type'\s*:\s*'([^']*)'\s*[,|]\s*'filler'\s*:\s*'([^']*)'")


def parse_semantics(text):
    """Teacher string -> dict, or None if nothing usable.

    The teacher writes '|' in place of ',' (NeMo's own SLURP evaluator does the
    same replace before parsing). Truncated/malformed outputs fall back to regex
    extraction so a missing closing bracket doesn't throw away a correct intent."""
    if not isinstance(text, str):
        return None
    t = text.strip().replace("|", ",")
    try:
        d = ast.literal_eval(t)
        if isinstance(d, dict) and "scenario" in d and "action" in d:
            return d
    except (ValueError, SyntaxError, MemoryError, RecursionError, TypeError):
        pass
    sc, ac = _SC_RE.search(t), _AC_RE.search(t)
    if not (sc and ac):
        return None
    return {"scenario": sc.group(1), "action": ac.group(1),
            "entities": [{"type": a, "filler": b} for a, b in _ENT_RE.findall(t)]}


def render_semantics(scenario, action, entities, sep=", "):
    """Same text as NeMo's str({'scenario':..,'action':..,'entities':[..]}) target,
    with the structural ', ' replaced by the teacher's separator (e.g. '| ').
    With sep=', ' this is byte-identical to str(dict)."""
    q = repr
    ents = sep.join("{" + f"'type': {q(t)}{sep}'filler': {q(f)}" + "}" for t, f in entities)
    return "{" + f"'scenario': {q(scenario)}{sep}'action': {q(action)}{sep}'entities': [{ents}]" + "}"


def nemo_entities(sentence_annotation):
    """Entities exactly as NeMo's process_slurp_data.py extracts them for the teacher."""
    out = []
    for k in range(sentence_annotation.count("[")):
        span = sentence_annotation.split("[")[k + 1].split("]")[0]
        parts = span.split(":")
        if len(parts) < 2:
            continue
        out.append((parts[0].strip().lower(), parts[1].strip().lower()))
    return out


def semantics_intent(sem):
    if not sem or "scenario" not in sem or "action" not in sem:
        return None
    return f"{sem['scenario']}_{sem['action']}"


def semantics_entities(sem):
    out = []
    for ent in (sem or {}).get("entities", []) or []:
        if isinstance(ent, dict) and ent.get("type") and ent.get("filler"):
            out.append((str(ent["type"]).strip().lower(), str(ent["filler"]).strip().lower()))
    return out


def _norm_word(w):
    return re.sub(r"[^\w']", "", w.lower())


def semantics_to_tagged_text(sem, gold_tagged_text, known_slot_types):
    """
    Build the student's CTC target from the teacher's entities.

    The teacher outputs only (type, filler) pairs, not a transcript, so the
    entities are projected onto the gold transcript: each teacher filler is
    located in the gold words and wrapped as  <fill_TYPE> ... <end_fill>.
    Entities whose filler isn't found verbatim, or whose type the student vocab
    doesn't know, are dropped. Returns None if the teacher output is unusable.
    """
    from vocab import strip_tags, END_FILL_TOKEN

    if sem is None:
        return None
    words = strip_tags(gold_tagged_text).split()
    norm = [_norm_word(w) for w in words]
    used = [False] * len(words)
    spans = []  # (start, end, type)
    for typ, filler in semantics_entities(sem):
        if typ not in known_slot_types:
            continue
        ftoks = [t for t in (_norm_word(x) for x in filler.split()) if t]
        n = len(ftoks)
        if n == 0:
            continue
        for i in range(len(norm) - n + 1):
            if norm[i:i + n] == ftoks and not any(used[i:i + n]):
                spans.append((i, i + n, typ))
                for j in range(i, i + n):
                    used[j] = True
                break

    starts = {s: (e, t) for s, e, t in spans}
    out, i = [], 0
    while i < len(words):
        if i in starts:
            e, t = starts[i]
            out += [f"<fill_{t}>"] + words[i:e] + [END_FILL_TOKEN]
            i = e
        else:
            out.append(words[i])
            i += 1
    return " ".join(out)


def entities_to_tagged_text(sem):
    """Slot-only tagged string for scoring the teacher with metrics.slu_f1."""
    from vocab import END_FILL_TOKEN
    return " ".join(f"<fill_{t}> {f} {END_FILL_TOKEN}" for t, f in semantics_entities(sem))
